import os,sys,json,time,pathlib
sys.path.insert(0,str(pathlib.Path.cwd()))
os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8'
import torch,numpy as np
from revision.models import transformer,phase_switch,predict,seed_all
from revision.data import load_basin
from revision.analysis import binary_overrides,clone_masks,subset
from experiments.refine_steh import unit_list
from revision.common import write_json
seed_all(42);torch.set_num_threads(1)
f=pathlib.Path('outputs/steh_population_20261012/01013500/seed_42/L15/steh_with_q')
cfg=json.loads((f/'run_config.json').read_text());splits,meta=load_basin('data','01013500',cfg)
m=transformer(len(meta['feature_names']),cfg);m.load_state_dict(torch.load(f/'trained.pt',weights_only=False,map_location='cpu')['state_dict']);m.to('cuda');phase_switch(m,'mask',cfg['target_activation_sparsity']);m.eval()
base=binary_overrides(m,'cuda');val=subset(splits['val'],512,cfg['analysis_seed']);masks=[]
for key,layer,i in unit_list(base)[:20]:
 t=clone_masks(base);t[key][layer][i]=0;masks.append(t)
x=torch.from_numpy(val['x']).to('cuda')
def sequential():return np.stack([predict(m,val,cfg,t) for t in masks])
@torch.no_grad()
def batched(chunk):
 outputs=[]
 for start in range(0,len(masks),chunk):
  group=masks[start:start+chunk];stack={}
  for key,value in base.items():
   stack[key]=({layer:torch.stack([t[key][layer] for t in group]) for layer in value} if isinstance(value,dict) else torch.stack([t[key] for t in group]))
  batches=[]
  for stop in range(0,len(x),128):
   xb=x[stop:stop+128]
   batches.append(torch.vmap(lambda z:m(xb,return_intermediates=False,**z).pred,in_dims=0,randomness='error')(stack))
  outputs.append(torch.cat(batches,dim=1))
 return torch.cat(outputs).cpu().numpy()
results=[];reference=sequential()
for chunk in [1,2,4,8]:
 try:
  function=sequential if chunk==1 else lambda:batched(chunk)
  actual=function();np.testing.assert_allclose(actual,reference,rtol=3e-5,atol=3e-6)
  times=[]
  for repeat in range(2):
   torch.cuda.synchronize();started=time.perf_counter();actual=function();torch.cuda.synchronize();times.append(time.perf_counter()-started)
  results.append({'chunk':chunk,'seconds':times,'max_abs_prediction_difference':float(abs(actual-reference).max())})
 except Exception as error:results.append({'chunk':chunk,'error':str(error)})
write_json('/root/autodl-tmp/steh-performance/vmap-benchmark.json',{'status':'measurement only; active population method unchanged','station':'01013500','masks':20,'validation_days':len(x),'concurrent_main_workers':14,'results':results})
print(json.dumps(results))

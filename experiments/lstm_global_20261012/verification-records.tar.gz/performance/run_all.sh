#!/bin/bash
set -euo pipefail
source /root/miniconda3/etc/profile.d/conda.sh
conda activate steh
cd /root/autodl-tmp/Sparse-Transformer-In-Streamflow-Prediction
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
python -u run_revision.py prepare --config configs/revision_server_3090.json
python -u -m revision.audit --config configs/revision_server_3090.json --output-root outputs/revision_3090_data_audit
if ! python -u run_revision.py run --workers 14 --config configs/revision_server_3090.json; then
 echo 'Retrying only incomplete jobs at reduced concurrency'
 python -u run_revision.py run --workers 8 --config configs/revision_server_3090.json
fi
PYTHONPATH="$PWD" python -u /root/autodl-tmp/steh-performance/audit_complete.py
printf '\nALL_108_EXPERIMENTS_COMPLETE\n'

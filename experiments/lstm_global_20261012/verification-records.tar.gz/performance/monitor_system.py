import csv,time
from pathlib import Path
root=Path('/sys/fs/cgroup');out=Path('/root/autodl-tmp/steh-performance/cpu-memory-telemetry.csv')
previous=None
with out.open('w',buffering=1) as f:
 writer=csv.writer(f);writer.writerow(['unix_time','cpu_cores_used','cpu_quota_percent','memory_mib','throttled_usec_delta'])
 while True:
  vals={k:int(v) for k,v in (line.split() for line in (root/'cpu.stat').read_text().splitlines())};now=time.time()
  if previous:
   stamp,old=previous;cores=(vals['usage_usec']-old['usage_usec'])/1e6/(now-stamp)
   writer.writerow([now,cores,cores/14*100,int((root/'memory.current').read_text())/2**20,vals['throttled_usec']-old['throttled_usec']])
  previous=(now,vals);time.sleep(5)

import json
from pathlib import Path
import numpy as np,pandas as pd
from revision.runner import job_path
from revision.common import digest,write_json
out=Path('outputs/revision_3090');m=json.loads((out/'manifest.json').read_text());rows=[];paired={}
for j in m['jobs']:
 folder=job_path(out,j);s=json.loads((folder/'summary.json').read_text());p=pd.read_csv(folder/'predictions.csv')
 assert s['run_sha256']==digest({'job':j,'manifest':m})
 assert len(p)==s['metrics']['n'];assert np.isfinite(p[['observed','predicted']].to_numpy()).all()
 assert (folder/'trained.pt').is_file();assert (folder/'performance.json').is_file()
 dates=paired.setdefault(j['station'],s['test_dates_sha256']);assert dates==s['test_dates_sha256']
 if j['model']=='lstm':assert len(json.loads((folder/'lstm_tuning.json').read_text()))==4
 else:
  assert (folder/'interpretation.json').is_file();assert (folder/'probes.json').is_file()
 cfg=json.loads((folder/'run_config.json').read_text());assert cfg['batch_size']==128
 assert cfg['gpu_resident_data'] and cfg['adamw_fused'] and cfg['torch_threads']==1
 rows.append({'job':j,**json.loads((folder/'performance.json').read_text())})
assert len(rows)==108
summary=pd.read_csv(out/'summary.csv');assert len(summary)==108 and (summary.status=='complete').all()
assert not any(v['incomplete'] for v in json.loads((out/'sample_estimates.json').read_text()))
base=json.loads(Path('configs/revision_minimal.json').read_text());allowed={'output_root','torch_threads','gpu_resident_data','adamw_fused'}
assert all(m['config'][k]==v for k,v in base.items() if k not in allowed)
report={'status':'PASS','completed_jobs':108,'steh_jobs':72,'lstm_jobs':36,'lstm_candidate_trainings':144,'sampled_basins':len(m['sample']),'independent_seeds':m['config']['seeds'],'batch_size':128,'prespecified_protocol_preserved':True,'paired_test_dates_equal':True,'all_predictions_finite':True,'performance':rows}
write_json(out/'completion_audit.json',report);print('COMPLETION_AUDIT_PASS: 108/108 jobs; protocol, checkpoint, finite prediction, tuning and paired-date checks passed')

import argparse, json, time, resource, os
from pathlib import Path
import torch
from revision.models import transformer, phase_switch, LSTM, seed_all
p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--threads',type=int,default=4);p.add_argument('--steps',type=int,default=8);p.add_argument('--profile',action='store_true');p.add_argument('--fused',action='store_true');a=p.parse_args()
root=Path('/root/autodl-tmp/steh-performance');cfg=json.loads(Path('configs/revision_minimal.json').read_text());torch.set_num_threads(a.threads);seed_all(42)
rows=[]
for kind in ['dense','sparse','mask','lstm']:
 model=(LSTM(8,128,2,.1) if kind=='lstm' else transformer(8,cfg)).cuda()
 if kind!='lstm':phase_switch(model,kind,.8 if kind!='dense' else 0.)
 opt=torch.optim.AdamW([v for v in model.parameters() if v.requires_grad],lr=.001,fused=a.fused)
 x=torch.randn(128,15,8,device='cuda');y=torch.randn(128,device='cuda')
 def step():
  if kind in ['sparse','mask']:model.apply_global_weight_sparsity(.9,'neuronwise',2)
  opt.zero_grad(set_to_none=True);out=model(x) if kind=='lstm' else model(x,return_intermediates=False).pred
  loss=(out-y).square().mean()
  if kind=='mask':loss=loss+model.mask_regularization()*.0001
  loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
  if kind in ['sparse','mask']:model.apply_global_weight_sparsity(.9,'neuronwise',2)
 for _ in range(2):step()
 torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();cpu=resource.getrusage(resource.RUSAGE_SELF);start=time.perf_counter()
 for _ in range(a.steps):step()
 torch.cuda.synchronize();elapsed=time.perf_counter()-start;c=resource.getrusage(resource.RUSAGE_SELF)
 row=dict(label=a.label,kind=kind,threads=a.threads,steps=a.steps,seconds=elapsed,step_ms=elapsed/a.steps*1000,samples_per_second=128*a.steps/elapsed,cpu_seconds=c.ru_utime+c.ru_stime-cpu.ru_utime-cpu.ru_stime,gpu_peak_mb=torch.cuda.max_memory_allocated()/2**20)
 rows.append(row);print(json.dumps(row),flush=True)
 if a.profile and kind=='sparse':
  with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as prof:step();torch.cuda.synchronize()
  (root/(a.label+'-profiler.txt')).write_text(prof.key_averages().table(sort_by='self_cpu_time_total',row_limit=20))
 del model,opt;torch.cuda.empty_cache()
(root/(a.label+'.json')).write_text(json.dumps(rows,indent=2))

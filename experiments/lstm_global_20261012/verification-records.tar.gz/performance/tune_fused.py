import os,sys,time,json,subprocess
from pathlib import Path
root=Path('/root/autodl-tmp/steh-performance')
rows=[]
for threads,workers in [(1,1),(1,12),(1,14)]:
 label=f'fused-t{threads}-w{workers}';t=time.perf_counter();processes=[]
 for i in range(workers):
  log=(root/f'{label}-{i}.log').open('w')
  processes.append(subprocess.Popen([sys.executable,str(root/'benchmark.py'),'--label',f'{label}-{i}','--threads',str(threads),'--steps','120','--fused'],stdout=log,stderr=subprocess.STDOUT))
 for proc in processes:
  if proc.wait():raise RuntimeError('benchmark failed')
 reports=[json.loads((root/f'{label}-{i}.json').read_text()) for i in range(workers)]
 by_kind={kind:sum(r['seconds'] for report in reports for r in report if r['kind']==kind)/workers for kind in ['dense','sparse','mask','lstm']}
 weighted=by_kind['dense']+by_kind['sparse']+by_kind['mask']+6*by_kind['lstm']
 row=dict(label=label,threads=threads,workers=workers,wall_seconds=time.perf_counter()-t,mean_seconds_by_kind=by_kind,weighted_seconds_per_worker=weighted,weighted_capacity=workers/weighted)
 rows.append(row);(root/'fused-tuning.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)

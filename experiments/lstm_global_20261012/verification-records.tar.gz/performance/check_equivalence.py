import importlib.util,json,torch,numpy as np
from pathlib import Path
from src.flood_transformer.sparsity import apply_topk_sparsity_neuronwise
from revision.models import loader,transformer,predict,seed_all
sp=importlib.util.spec_from_file_location('legacy_sparse','/root/autodl-tmp/steh-performance/baseline/sparsity.py');old=importlib.util.module_from_spec(sp);sp.loader.exec_module(old)
cases=0
for device in ['cpu','cuda']:
 for shape in [(7,11),(32,16),(256,128)]:
  for axis in [0,1]:
   for minimum in [0,2,50]:
    for ratio in [0,.2,.9,.999,1]:
     torch.manual_seed(130);w=torch.randn(*shape,device=device)
     actual=apply_topk_sparsity_neuronwise(w,ratio,axis,minimum);expected=old.apply_topk_sparsity_neuronwise(w,ratio,axis,minimum)
     assert torch.equal(actual,expected),(device,shape,axis,minimum,ratio)
     cases+=1
seed_all(42)
split={'x':np.arange(35*4*3,dtype=np.float32).reshape(35,4,3),'y':np.arange(35,dtype=np.float32)}
cfg={'batch_size':8,'seed':42,'num_workers':0,'device':'cuda'}
a=loader(split,cfg,True);b=loader(split,cfg|{'gpu_resident_data':True},True)
for epoch in range(3):
 for (x,y),(u,v) in zip(a,b):
  assert torch.equal(x,u.cpu());assert torch.equal(y,v.cpu())
print('EQUIVALENCE_PASS',cases,'sparsity cases; 3 epochs exact sampling order')
